package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelComplaintManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
