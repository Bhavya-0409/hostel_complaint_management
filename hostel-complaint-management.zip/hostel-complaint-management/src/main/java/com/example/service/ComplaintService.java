package com.example.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.example.model.Complaint;
import com.example.repository.ComplaintRepository;

@Service
public class ComplaintService {
    private final ComplaintRepository repo;

    public ComplaintService(ComplaintRepository repo) {
        this.repo = repo;
    }

    public Complaint addComplaint(Complaint complaint) {
        return repo.save(complaint);
    }

    public List<Complaint> getAllComplaints() {
        return repo.findAll();
    }

    public void deleteComplaint(Long id) {
        repo.deleteById(id);
    }
}