package com.example.controller;

import com.example.model.Complaint;
import com.example.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/complaints")
// Updated to a common default port for Vite, but keep your 5173 if that's what you use!
@CrossOrigin(origins = "http://localhost:5173") 
public class ComplaintController {

    @Autowired
    private ComplaintRepository repository;

    @GetMapping
    public List<Complaint> getAll() {
        // Returns all complaints sorted by ID descending (newest first)
        return repository.findAll();
    }

    @PostMapping
    public Complaint create(@RequestBody Complaint complaint) {
        // Since we set default values in the Model, this will save with "PENDING"
        return repository.save(complaint);
    }

    /**
     * Generic status update endpoint.
     * Matches the React call: axios.put(`${API_URL}/${id}/status`, { status: newStatus })
     */
    @PutMapping("/{id}/status")
    public Complaint updateStatus(@PathVariable Long id, @RequestBody Map<String, String> request) {
        Complaint complaint = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + id));
        
        String newStatus = request.get("status");
        if (newStatus != null) {
            complaint.setStatus(newStatus);
        }
        
        return repository.save(complaint);
    }
}