import React from 'react';

const ComplaintList = ({ complaints }) => {
  return (
    <div style={{ marginTop: '20px' }}>
      <h3>Recent Complaints</h3>
      {complaints.length === 0 ? <p>No complaints yet.</p> : (
        complaints.map((c) => (
          <div key={c.id} style={{ borderBottom: '1px solid #cbd5e1', padding: '10px' }}>
            <strong>{c.title}</strong> - <span style={{ color: 'orange' }}>{c.status}</span>
            <p style={{ fontSize: '14px', color: '#64748b' }}>{c.description}</p>
          </div>
        ))
      )}
    </div>
  );
};

export default ComplaintList;