import React, { useState } from 'react';
import axios from 'axios';

const ComplaintForm = ({ onComplaintAdded }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newComplaint = { title, description };
    await axios.post("http://localhost:8080/api/complaints", newComplaint);
    
    setTitle('');
    setDescription('');
    onComplaintAdded(); // This tells the List to refresh
  };

  return (
    <div style={{ background: '#f1f5f9', padding: '20px', borderRadius: '10px' }}>
      <h3>Submit New Complaint</h3>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" placeholder="Title" value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
        />
        <textarea 
          placeholder="Description" value={description}
          onChange={(e) => setDescription(e.target.value)}
          style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
        />
        <button type="submit" style={{ background: '#2563eb', color: 'white', border: 'none', padding: '10px 20px', cursor: 'pointer' }}>
          Submit Issue
        </button>
      </form>
    </div>
  );
};

export default ComplaintForm;