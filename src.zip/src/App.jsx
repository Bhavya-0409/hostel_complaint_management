import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  ShieldAlert, Clock, CheckCircle, Lock, Eye, 
  Truck, Search, MapPin, Cpu, ShieldCheck, User, HardHat 
} from 'lucide-react';

const API_URL = "http://localhost:8080/api/complaints";
const STUDENT_SECRET = "HOSTEL2026"; 

function App() {
  const [role, setRole] = useState(null); 
  const [complaints, setComplaints] = useState([]);
  const [filter, setFilter] = useState('ALL'); 
  const [roomSearch, setRoomSearch] = useState(''); 

  // Form States
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('PLUMBING'); // Added Category State back
  const [roomNo, setRoomNo] = useState(''); 
  const [accessKey, setAccessKey] = useState('');

  // Auth States
  const [isWardenAuth, setIsWardenAuth] = useState(false);
  const [password, setPassword] = useState('');

  useEffect(() => {
    // Only fetch if role is set and warden is authenticated
    if (role === 'student' || (role === 'warden' && isWardenAuth)) {
      fetchComplaints();
    }
  }, [role, isWardenAuth]);

  const fetchComplaints = async () => {
    try {
      const res = await axios.get(API_URL);
      setComplaints(Array.isArray(res.data) ? res.data : []);
    } catch (err) { setComplaints([]); }
  };

  const handleUpdateStatus = async (id, newStatus) => {
    setComplaints(prev => prev.map(c => c.id === id ? { ...c, status: newStatus } : c));
    try {
      await axios.put(`${API_URL}/${id}/status`, { status: newStatus });
    } catch (err) { fetchComplaints(); }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (accessKey !== STUDENT_SECRET) {
        alert("⛔ ACCESS_KEY_INVALID");
        return;
    }
    try {
        await axios.post(API_URL, { 
            title: title.toUpperCase(), 
            description, 
            category, // Added category to post body
            roomNo, 
            status: 'PENDING' 
        }); 
        setTitle(''); setDescription(''); setAccessKey(''); setRoomNo('');
        fetchComplaints();
    } catch (err) { alert("❌ TRANSMISSION_FAILED"); }
  };

  const getStatusDisplay = (status) => {
    switch(status) {
      case 'PENDING': return { label: 'AWAITING_REVIEW', color: '#ff3e3e', icon: <Clock size={12}/> };
      case 'ACKNOWLEDGED': return { label: 'IN_PROGRESS', color: '#00f2ff', icon: <Truck size={12}/> };
      case 'RESOLVED': return { label: 'RESOLVED', color: '#22ff00', icon: <CheckCircle size={12}/> };
      default: return { label: status, color: '#fff', icon: null };
    }
  };

  const filteredComplaints = (complaints || [])
    .filter(c => filter === 'ALL' ? true : c.status === filter)
    .filter(c => String(c.roomNo || "").toLowerCase().includes(roomSearch.toLowerCase()));

  // --- 1. LANDING PAGE ---
  if (!role) {
    return (
      <div style={styles.landingWrapper}>
        <div style={styles.brandCenter}>
          <ShieldAlert size={60} color="#00f2ff" style={{filter: 'drop-shadow(0 0 15px #00f2ff)'}} />
          <h1 style={styles.glitchTitle}>HOSTEL COMPLAINT MANAGEMENT SYSTEM</h1>
          <p style={styles.statusText}>TERMINAL_READY // SELECT_ACCESS_PROTOCOL</p>
        </div>
        <div style={styles.splitLayout}>
          <div style={styles.roleZone} onClick={() => setRole('student')}>
            <User size={50} color="#00f2ff" />
            <h2 style={{color: '#00f2ff', letterSpacing: '3px', marginTop: '20px'}}>Student Portal</h2>
            <div style={styles.actionLineBlue}></div>
          </div>
          <div style={styles.roleZone} onClick={() => { setRole('warden'); setPassword(''); }}>
            <HardHat size={50} color="#bc13fe" />
            <h2 style={{color: '#bc13fe', letterSpacing: '3px', marginTop: '20px'}}>Warden Portal</h2>
            <div style={styles.actionLinePurple}></div>
          </div>
        </div>
      </div>
    );
  }

  // --- 2. WARDEN AUTH ---
  if (role === 'warden' && !isWardenAuth) {
    return (
      <div style={styles.fullPageCenter}>
        <div style={styles.authCard}>
          <Lock size={40} color="#bc13fe" style={{marginBottom:'20px'}} />
          <h2 style={{color:'#bc13fe', letterSpacing:'2px'}}>ENCRYPTED_LAYER</h2>
          <form onSubmit={(e) => { e.preventDefault(); if (password === 'admin123') setIsWardenAuth(true); else alert("WRONG KEY"); }} style={styles.form}>
            <input type="password" placeholder="AUTHORITY_KEY" style={styles.neonInput} value={password} onChange={(e) => setPassword(e.target.value)} required />
            <button type="submit" style={styles.neonBtnPurple}>AUTHORIZE</button>
            <button type="button" onClick={() => setRole(null)} style={{background:'none', border:'none', color:'#444', marginTop:'10px', cursor:'pointer'}}>BACK</button>
          </form>
        </div>
      </div>
    );
  }

  // --- 3. DASHBOARD ---
  return (
    <div style={styles.dashboardWrapper}>
      <nav style={styles.neonNavbar}>
        <div style={styles.navBrand}><Cpu size={20} /> <span>SYS_ADMIN // {role.toUpperCase()}</span></div>
        <button onClick={() => {setRole(null); setIsWardenAuth(false);}} style={styles.neonLogoutBtn}>DISCONNECT</button>
      </nav>

      <div style={styles.scrollArea}>
        <div style={styles.container}>
          
          {role === 'student' && (
            <div style={styles.glassCard}>
              <h3 style={styles.neonHeading}>NEW_ENTRY_LOG</h3>
              <form onSubmit={handleSubmit} style={styles.form}>
                <div style={styles.row}>
                    <input style={{...styles.neonInput, flex: 2}} placeholder="ISSUE SUBJECT" value={title} onChange={e => setTitle(e.target.value)} required />
                    <input style={{...styles.neonInput, flex: 1}} placeholder="ROOM NO" value={roomNo} onChange={e => setRoomNo(e.target.value)} required />
                    {/* CATEGORY LIST ADDED BACK HERE */}
                    <select style={{...styles.neonInput, flex: 1}} value={category} onChange={e => setCategory(e.target.value)}>
                        <option value="PLUMBING">PLUMBING</option>
                        <option value="ELECTRICAL">ELECTRICAL</option>
                        <option value="FOOD/MESS">FOOD/MESS</option>
                        <option value="CLEANING">CLEANING</option>
                        <option value="OTHERS">OTHERS</option>
                    </select>
                </div>
                <textarea style={styles.neonTextarea} placeholder="DETAILS..." value={description} onChange={e => setDescription(e.target.value)} required />
                <div style={styles.bottomFormRow}>
                    <div style={styles.neonVerifyBox}><ShieldCheck size={18} color="#00f2ff" /><input type="password" placeholder="KEY" style={styles.neonVerifyInput} value={accessKey} onChange={e => setAccessKey(e.target.value)} required /></div>
                    <button type="submit" style={styles.neonBtnBlueSmall}>TRANSMIT</button>
                </div>
              </form>
            </div>
          )}

          <div style={styles.glassCard}>
            <div style={styles.listHeader}>
                <div style={styles.filterRow}>
                    <div style={styles.neonFilterGroup}>
                        {['ALL', 'PENDING', 'ACKNOWLEDGED', 'RESOLVED'].map(f => (
                            <button key={f} onClick={() => setFilter(f)} style={{...styles.filterBtn, color: filter === f ? '#00f2ff' : '#444'}}>{f}</button>
                        ))}
                    </div>
                    <div style={styles.neonSearchBox}><Search size={14} color="#00f2ff" /><input style={styles.neonSearchInput} placeholder="SEARCH ROOM..." value={roomSearch} onChange={(e) => setRoomSearch(e.target.value)} /></div>
                </div>
            </div>

            <div style={styles.listContainer}>
                {filteredComplaints.map(c => {
                  const s = getStatusDisplay(c.status);
                  return (
                    <div key={c.id} style={styles.neonItem}>
                        <div style={{flex:1}}>
                            <div style={styles.itemHeader}>
                                <div style={styles.roomTag}>RM_{c.roomNo || '??'}</div>
                                <h4 style={styles.itemTitle}>{c.title}</h4>
                                <span style={{...styles.statusLabel, color: s.color}}>{s.icon} {s.label}</span>
                            </div>
                            <p style={styles.neonItemDesc}>{c.description}</p>
                            <span style={{fontSize:'10px', color:'#555'}}>CATEGORY: {c.category}</span>
                        </div>
                        
                        {role === 'warden' && (
                            <div style={styles.actionArea}>
                                {c.status === 'PENDING' && (
                                    <button onClick={() => handleUpdateStatus(c.id, 'ACKNOWLEDGED')} style={styles.dispatchBtn}>
                                        <Eye size={12}/> ACKNOWLEDGE
                                    </button>
                                )}
                                {c.status === 'ACKNOWLEDGED' && (
                                    <button onClick={() => handleUpdateStatus(c.id, 'RESOLVED')} style={styles.neonResolveBtn}>
                                        <CheckCircle size={12}/> MARK_RESOLVED
                                    </button>
                                )}
                                {c.status === 'RESOLVED' && (
                                    <span style={{color:'#22ff0033', fontSize:'11px', letterSpacing:'1px'}}>✓ ARCHIVED</span>
                                )}
                            </div>
                        )}
                    </div>
                  )
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  // LANDING PAGE STYLES
  landingWrapper: { height: '100vh', width: '100%', backgroundColor: '#050507', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', fontFamily: 'monospace' },
  brandCenter: { textAlign: 'center', marginBottom: '50px' },
  glitchTitle: { color: '#fff', fontSize: '32px', letterSpacing: '8px', margin: '15px 0' },
  statusText: { color: '#444', fontSize: '12px', letterSpacing: '4px' },
  splitLayout: { display: 'flex', width: '90%', maxWidth: '1000px', height: '300px', gap: '25px' },
  roleZone: { flex: 1, border: '1px solid #1a1a1c', borderRadius: '24px', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', cursor: 'pointer', transition: '0.4s', backgroundColor: '#0a0a0c' },
  actionLineBlue: { width: '40px', height: '2px', backgroundColor: '#00f2ff', marginTop: '25px' },
  actionLinePurple: { width: '40px', height: '2px', backgroundColor: '#bc13fe', marginTop: '25px' },

  // DASHBOARD STYLES
  fullPageCenter: { height: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#050507' },
  authCard: { padding: '50px', backgroundColor: '#0a0a0c', borderRadius: '24px', border: '1px solid #1a1a1c', textAlign: 'center' },
  dashboardWrapper: { height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#050507', color: '#e2e8f0', fontFamily: 'monospace' },
  neonNavbar: { padding: '0 40px', height: '70px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #222', background: '#0a0a0c' },
  navBrand: { color: '#00f2ff', display: 'flex', alignItems: 'center', gap: '10px' },
  scrollArea: { flex: 1, overflowY: 'auto', padding: '30px 20px' },
  container: { maxWidth: '1000px', margin: '0 auto' },
  glassCard: { backgroundColor: 'rgba(15, 15, 20, 0.9)', padding: '25px', borderRadius: '16px', border: '1px solid #1a1a1c', marginBottom: '25px' },
  neonHeading: { color: '#00f2ff', fontSize: '12px', letterSpacing: '2px', marginBottom: '20px' },
  form: { display: 'flex', flexDirection: 'column', gap: '15px' },
  row: { display: 'flex', gap: '12px' },
  neonInput: { padding: '12px', borderRadius: '8px', border: '1px solid #333', backgroundColor: '#000', color: '#fff', outline: 'none' },
  neonTextarea: { padding: '12px', borderRadius: '8px', border: '1px solid #333', backgroundColor: '#000', color: '#fff', height: '80px', resize: 'none' },
  bottomFormRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  neonBtnBlueSmall: { padding: '12px 25px', backgroundColor: '#00f2ff', color: '#000', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' },
  neonBtnPurple: { padding: '12px 30px', border: '1px solid #bc13fe', color: '#bc13fe', background: 'none', borderRadius: '6px', cursor: 'pointer', marginTop: '10px' },
  neonLogoutBtn: { border: '1px solid #ff3e3e33', color: '#ff3e3e', background: 'none', padding: '8px 15px', borderRadius: '6px', cursor: 'pointer' },
  filterRow: { display: 'flex', justifyContent: 'space-between', marginBottom: '20px' },
  neonItem: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px', backgroundColor: 'rgba(255,255,255,0.02)', borderRadius: '12px', marginBottom: '12px', border: '1px solid #1a1a1c' },
  itemHeader: { display: 'flex', alignItems: 'center', gap: '15px', marginBottom: '8px' },
  itemTitle: { margin: 0, color: '#fff', fontSize: '16px' },
  roomTag: { backgroundColor: '#00f2ff15', color: '#00f2ff', padding: '4px 10px', borderRadius: '6px', fontSize: '11px', border: '1px solid #00f2ff33' },
  statusLabel: { fontSize: '10px', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '6px' },
  neonItemDesc: { color: '#777', fontSize: '13px', margin: '0 0 5px 0' },
  actionArea: { minWidth: '150px', display: 'flex', justifyContent: 'flex-end' },
  dispatchBtn: { border: '1px solid #ff9e00', color: '#ff9e00', background: 'none', padding: '8px 15px', borderRadius: '6px', fontSize: '11px', cursor: 'pointer' },
  neonResolveBtn: { border: '1px solid #22ff00', color: '#22ff00', background: 'none', padding: '8px 15px', borderRadius: '6px', fontSize: '11px', cursor: 'pointer' },
  neonSearchBox: { display: 'flex', alignItems: 'center', gap: '10px', backgroundColor: '#000', padding: '8px 15px', borderRadius: '8px', border: '1px solid #222' },
  neonSearchInput: { background: 'none', border: 'none', color: '#fff', outline: 'none', fontSize: '13px' },
  neonFilterGroup: { display: 'flex', gap: '20px' },
  filterBtn: { background: 'none', border: 'none', cursor: 'pointer', fontSize: '11px', fontWeight: 'bold' },
  neonVerifyBox: { display: 'flex', alignItems: 'center', gap: '10px', backgroundColor: '#000', padding: '8px 15px', borderRadius: '8px' },
  neonVerifyInput: { background: 'none', border: 'none', color: '#00f2ff', outline: 'none', width: '80px' }
};

export default App;